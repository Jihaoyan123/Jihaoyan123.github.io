# -*- coding: utf-8 -*-

from mod.common.mod import Mod
import mod.server.extraServerApi as serverApi
import mod.client.extraClienApi as clientApi

@Mod.Binding(name="Script_NeteaseMod", version="0.0.1")
class Script_NeteaseMod(object):

    def __init__(self):
        pass

    @Mod.InitServer()
    def Script_NeteaseModServerInit(self):
        serverApi.RegisterSystem("Script_NeteaseModSystem", "Server", "Script_NeteaseModSystem.NeteaseModServerSystem.NeteaseServerSystem")
        

    @Mod.DestroyServer()
    def Script_NeteaseModServerDestroy(self):
        pass

    @Mod.InitClient()
    def Script_NeteaseModClientInit(self):
        clientApi.RegisterSystem("Script_NeteaseModSystem", "Client", "Script_NeteaseModSystem.NeteaseModClientSystem.NeteaseClientSystem")


    @Mod.DestroyClient()
    def Script_NeteaseModClientDestroy(self):
        pass
