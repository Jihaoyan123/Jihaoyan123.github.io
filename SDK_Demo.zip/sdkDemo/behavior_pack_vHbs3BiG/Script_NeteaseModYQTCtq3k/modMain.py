# -*- coding: utf-8 -*-

from mod.common.mod import Mod


@Mod.Binding(name="Script_NeteaseModYQTCtq3k", version="0.0.1")
class Script_NeteaseModYQTCtq3k(object):

    def __init__(self):
        pass

    @Mod.InitServer()
    def Script_NeteaseModYQTCtq3kServerInit(self):
        pass

    @Mod.DestroyServer()
    def Script_NeteaseModYQTCtq3kServerDestroy(self):
        pass

    @Mod.InitClient()
    def Script_NeteaseModYQTCtq3kClientInit(self):
        pass

    @Mod.DestroyClient()
    def Script_NeteaseModYQTCtq3kClientDestroy(self):
        pass
